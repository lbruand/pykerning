"""Vendored dependencies for typesetting algorithms."""
